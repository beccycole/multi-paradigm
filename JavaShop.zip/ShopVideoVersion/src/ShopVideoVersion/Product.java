package ShopVideoVersion;

public class Product {
	private String name;
	private double Price;
	
	public Product(String name, double price) {
		this.name = name;
		Price = price;
	}

	public String getName() {
		return name;
	}

	public double getPrice() {
		return Price;
	}

	@Override
	public String toString() {
		return "Product [name=" + name + ", Price=" + Price + "]";
	}
	
	
	

}
